// MIT License
// 
// Copyright(c) 2020 Arthur Bacon and Kevin Dill
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this softwareand associated documentation files(the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and /or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions :
// 
// The above copyright noticeand this permission notice shall be included in all
// copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#include "Mob.h"

#include "Constants.h"
#include "Game.h"
#include "Player.h"

#include <algorithm>
#include <vector>


Mob::Mob(const iEntityStats& stats, const Vec2& pos, bool isNorth)
    : Entity(stats, pos, isNorth)
    , m_pWaypoint(NULL)
{
    assert(dynamic_cast<const iEntityStats_Mob*>(&stats) != NULL);
}

void Mob::tick(float deltaTSec)
{
    // Tick the entity first.  This will pick our target, and attack it if it's in range.
    Entity::tick(deltaTSec);

    // if our target isn't in range, move towards it.
    if (!targetInRange())
    {
        move(deltaTSec);
    }
    
	//We still want to check for collisions even when we can't move I think...
    std::vector<Entity*> collisions = checkCollision();
    if (!collisions.empty()) {
        for (Entity* mob : collisions) {
            if (mob != nullptr)
            {
                processCollision(mob, deltaTSec);
            }
        }
    }
	
}

void Mob::move(float deltaTSec)
{
    // If we have a target and it's on the same side of the river, we move towards it.
    //  Otherwise, we move toward the bridge.
    bool bMoveToTarget = false;
    if (!!m_pTarget)
    {    
        bool imTop = m_Pos.y < (GAME_GRID_HEIGHT / 2);
        bool otherTop = m_pTarget->getPosition().y < (GAME_GRID_HEIGHT / 2);

        if (imTop == otherTop)
        {
            bMoveToTarget = true;
        }
    }

    Vec2 destPos;
    if (bMoveToTarget)
    { 
        m_pWaypoint = NULL;
        destPos = m_pTarget->getPosition();
    }
    else
    {
        if (!m_pWaypoint)
        {
            m_pWaypoint = pickWaypoint();
        }
        destPos = m_pWaypoint ? *m_pWaypoint : m_Pos;
    }

    // Actually do the moving
    Vec2 moveVec = destPos - m_Pos;
    float distRemaining = moveVec.normalize();
    float moveDist = m_Stats.getSpeed() * deltaTSec;

    // if we're moving to m_pTarget, don't move into it
    if (bMoveToTarget)
    {
        assert(m_pTarget);
        distRemaining -= (m_Stats.getSize() + m_pTarget->getStats().getSize()) / 2.f;
        distRemaining = std::max(0.f, distRemaining);
    }

    if (moveDist <= distRemaining)
    {
        m_Pos += moveVec * moveDist;
    }
    else
    {
        m_Pos += moveVec * distRemaining;

        // if the destination was a waypoint, find the next one and continue movement
        if (m_pWaypoint)
        {
            m_pWaypoint = pickWaypoint();
            destPos = m_pWaypoint ? *m_pWaypoint : m_Pos;
            moveVec = destPos - m_Pos;
            moveVec.normalize();
            m_Pos += moveVec * distRemaining;
        }
    }

	
    // PROJECT 3: This is where your collision code will be called from
    std::vector<Entity*> otherMobs = checkCollision();
    if (!otherMobs.empty()) {
        for (Entity* mob : otherMobs) {

            processCollision(mob, deltaTSec);

        }
    }
	
}

const Vec2* Mob::pickWaypoint()
{
    float smallestDistSq = FLT_MAX;
    const Vec2* pClosest = NULL;

    for (const Vec2& pt : Game::get().getWaypoints())
    {
        // Filter out any waypoints that are behind (or barely in front of) us.
        // NOTE: (0, 0) is the top left corner of the screen
        float yOffset = pt.y - m_Pos.y;
        if ((m_bNorth && (yOffset < 1.f)) ||
            (!m_bNorth && (yOffset > -1.f)))
        {
            continue;
        }

        float distSq = m_Pos.distSqr(pt);
        if (distSq < smallestDistSq) {
            smallestDistSq = distSq;
            pClosest = &pt;
        }
    }

    return pClosest;
}

// PROJECT 3: 
//  1) return a vector of mobs that we're colliding with
//  2) handle collision with towers & river 
std::vector<Entity*> Mob::checkCollision()
{
    //for (const Mob* pOtherMob : Game::get().getMobs())
    //{
    //    if (this == pOtherMob) 
    //    {
    //        continue;
    //    }

    //    // PROJECT 3: YOUR CODE CHECKING FOR A COLLISION GOES HERE
    //}

	std::vector<Entity*> collisions;
    Player& p = Game::get().getPlayer(m_bNorth);
    Player& otherP = Game::get().getPlayer(!m_bNorth);
    std::vector<Entity*> mobs = p.getMobs();
    std::vector<Entity*> enemyMobs = otherP.getMobs();
    if (enemyMobs.size() > 0) 
    {
		mobs.insert(mobs.end(), enemyMobs.begin(), enemyMobs.end());
	}
    std::vector<Entity*> enemyBuildings = otherP.getBuildings();
	if(enemyBuildings.size() > 0)
	{
        for(Entity * building : enemyBuildings)
        {
	        if(building != nullptr)
	        {
                mobs.push_back(building);
	        }
        }
	}
	for(Entity* mob : mobs)
	{
		if(this == mob)
		{
            continue;
		}
        else
        {
            float otherSize = mob->getStats().getSize();
            Vec2 otherPos = mob->getPosition();
            float avgSize = (m_Stats.getSize() + otherSize) / 2.f;
            Vec2 distance = m_Pos - otherPos;
        	if(abs(distance.x) < avgSize && abs(distance.y) < avgSize)
        	{   
                collisions.push_back(mob);
        	}
	        
        }
	}
    return collisions;
}

void Mob::processCollision(Entity* otherMob, float deltaTSec)
{
    // PROJECT 3: YOUR COLLISION HANDLING CODE GOES HERE
	//If we cannot dynamically cast this entity* to a mob*, we have an invalid mob (a building or TODO: a river)
    bool isARiver = false;
	if(otherMob == nullptr)
	{
        isARiver = true;
	}
    bool isAMob = true;
    Mob* mob = dynamic_cast<Mob*>(otherMob);
    if (mob == nullptr)
    {
        isAMob = false;
    }
    //Size checks
    float otherMass = 0.f;
	//If this is a mob, get its actual mass
    if (isAMob)
    {
        otherMass = mob->getStats().getMass();
    }
	//If it's not a mob, set mass to FLT_MAX
    else
    {
        otherMass = FLT_MAX;
    }
    bool smaller = m_Stats.getMass() < otherMass;
    bool sameSize = m_Stats.getMass() == otherMass;


    //Direction check
    //degrees --> radians
    float tolerance = 75.f * (3.141592653589793f / 180.0f);
    //We have where the two mobs are generally headed to, let's see if they're in the same direction
    //NOTE: Target refers to where a mob would move to (so for buildings, it has no "target" to move to, although it will target
    //mobs to attack)
    Vec2 target;
    if (m_pTarget)
    {
        target = m_pTarget->getPosition();
    }
    else
    {
        target = m_Pos;
    }
    Vec2 toTarget = target - m_Pos;


    Vec2 otherTarget;
	//If not a mob, get the position of the building for the "target"
    if (!isAMob)
    {
        otherTarget = otherMob->getPosition();
    }
	//If a mob, either use its target as its "target" or its own position as its "target" if there is no target position
    else {
	    if (mob->m_pTarget)
	    {
	        otherTarget = mob->m_pTarget->getPosition();
	    }
	    else
	    {
	        otherTarget = mob->getPosition();
	    }
	}
	
	Vec2 toOtherTarget = otherTarget - otherMob->getPosition();

    //cos (angle) = dot product / (magnitude1 * magnitude2)
    float dot = (toTarget.x * toOtherTarget.x) + (toTarget.y * toOtherTarget.y);
    float magnitudes = target.dist(m_Pos) * otherTarget.dist(otherMob->getPosition());
    float angle = 1.f / cosf(dot / magnitudes);
    bool sameDirection = angle < tolerance;

    bool behind = m_Pos.y < otherMob->getPosition().y;
	
	//If we're of less mass than the other mob, activate collision avoidance
	//Also, if we're behind a mob in the same direction with the same size
	//And also if we are in the opposite direction of a same sized mob
    if (smaller || (sameSize && sameDirection && behind) || (sameSize && !sameDirection))
    {
    	//If the adjustment vector is purely vertical, add a horizontal force so mobs can squeeze past each other
        float horizontalThreshold = 2.f;
        float horizontalAdjustment = otherMob->getStats().getSize() / 2;
    	
        Vec2 otherPosn = otherMob->getPosition();
    	
    	//Our adjustment vector (starts as the difference between the two vectors)
        Vec2 adjustment = otherPosn - m_Pos;
        if (adjustment.x < horizontalThreshold)
        {
            adjustment.x += horizontalAdjustment;
        }

    	//Distance between both mobs
        float distance = m_Pos.dist(otherPosn);

    	//Average size between the two mobs is our threshold
    	float mySize = this->getStats().getSize();
        float otherSize = otherMob->getStats().getSize();
        float threshold = (mySize + otherSize) / 2;

    	//Difference between threshold and distance determines how strong our collision avoidance force is
        float diff = threshold - distance;

    	//Normalize adjustment vector and apply difference scaling factor
        adjustment.normalize();
        adjustment *= diff;

    	

    	//Apply adjustment
        m_Pos -= adjustment * this->getStats().getSpeed() * deltaTSec;	
    }
}

